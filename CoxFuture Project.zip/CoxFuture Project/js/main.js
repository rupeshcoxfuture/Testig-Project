// ============================================================
//  SATPURA SAFARI — Main JavaScript
// ============================================================

document.addEventListener('DOMContentLoaded', function () {

  /* -------------------------------------------------------
     1. PRELOADER
  ------------------------------------------------------- */
  const preloader = document.querySelector('.preloader');
  if (preloader) {
    window.addEventListener('load', function () {
      setTimeout(() => preloader.classList.add('hidden'), 1800);
    });
  }

  /* -------------------------------------------------------
     2. NAVBAR — Scroll Effect
  ------------------------------------------------------- */
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 50);
    });
  }

  /* -------------------------------------------------------
     3. ACTIVE NAV LINK (based on current page)
  ------------------------------------------------------- */
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link[data-page]').forEach(link => {
    if (link.dataset.page === currentPage) {
      link.classList.add('active');
    }
  });

  /* -------------------------------------------------------
     4. BACK TO TOP BUTTON
  ------------------------------------------------------- */
  const backToTopBtn = document.getElementById('backToTop');
  if (backToTopBtn) {
    window.addEventListener('scroll', () => {
      backToTopBtn.classList.toggle('visible', window.scrollY > 300);
    });
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* -------------------------------------------------------
     5. SCROLL REVEAL (Intersection Observer)
  ------------------------------------------------------- */
  const fadeElements = document.querySelectorAll('.fade-in-up');
  if (fadeElements.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add('visible'), i * 80);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    fadeElements.forEach(el => observer.observe(el));
  }

  /* -------------------------------------------------------
     6. COUNTER ANIMATION
  ------------------------------------------------------- */
  function animateCounter(el, target, duration = 1800) {
    const start = 0;
    const startTime = performance.now();
    const suffix = el.dataset.suffix || '';
    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(start + (target - start) * eased) + suffix;
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  const counters = document.querySelectorAll('[data-counter]');
  if (counters.length > 0) {
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const target = parseInt(entry.target.dataset.counter);
          animateCounter(entry.target, target);
          counterObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    counters.forEach(c => counterObserver.observe(c));
  }

  /* -------------------------------------------------------
     7. BOOKING FORM VALIDATION & SUBMIT
  ------------------------------------------------------- */
  const bookingForm = document.getElementById('safariBookingForm');
  if (bookingForm) {
    // Set minimum date to today
    const dateInput = bookingForm.querySelector('#safariDate');
    if (dateInput) {
      const today = new Date().toISOString().split('T')[0];
      dateInput.setAttribute('min', today);
    }

    bookingForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const name    = document.getElementById('guestName').value.trim();
      const email   = document.getElementById('guestEmail').value.trim();
      const phone   = document.getElementById('guestPhone').value.trim();
      const date    = document.getElementById('safariDate').value;
      const zone    = document.getElementById('safariZone').value;
      const persons = document.getElementById('numPersons').value;

      if (!name || !email || !phone || !date || !zone || !persons) {
        showToast('⚠️ Please fill all required fields.', 'warning');
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showToast('⚠️ Please enter a valid email address.', 'warning');
        return;
      }
      if (!/^\+?[\d\s\-]{10,}$/.test(phone)) {
        showToast('⚠️ Please enter a valid phone number.', 'warning');
        return;
      }

      const submitBtn = bookingForm.querySelector('[type="submit"]');
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Booking...';
      submitBtn.disabled = true;

      setTimeout(() => {
        showToast('✅ Safari booked successfully! Check your email for confirmation.', 'success');
        submitBtn.innerHTML = '🐯 Book Safari Now';
        submitBtn.disabled = false;
        bookingForm.reset();
      }, 2000);
    });
  }

  /* -------------------------------------------------------
     8. CONTACT FORM
  ------------------------------------------------------- */
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = contactForm.querySelector('[type="submit"]');
      btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Sending...';
      btn.disabled = true;
      setTimeout(() => {
        showToast('✅ Message sent successfully! We will get back to you soon.', 'success');
        btn.innerHTML = '📩 Send Message';
        btn.disabled = false;
        contactForm.reset();
      }, 2000);
    });
  }

  /* -------------------------------------------------------
     9. TOAST NOTIFICATION
  ------------------------------------------------------- */
  function showToast(message, type = 'success') {
    const existing = document.querySelector('.custom-toast');
    if (existing) existing.remove();

    const colors = {
      success: { bg: '#2d6a4f', icon: '✅' },
      warning: { bg: '#d4a017', icon: '⚠️' },
      error:   { bg: '#c0392b', icon: '❌' }
    };
    const c = colors[type] || colors.success;

    const toast = document.createElement('div');
    toast.className = 'custom-toast';
    toast.innerHTML = message;
    toast.style.cssText = `
      position:fixed; top:100px; right:24px; z-index:99999;
      background:${c.bg}; color:#fff; padding:14px 22px;
      border-radius:12px; font-size:.9rem; font-weight:500;
      box-shadow:0 8px 30px rgba(0,0,0,.25); max-width:360px;
      animation:slideInRight .4s ease; font-family:'Poppins',sans-serif;
    `;

    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideInRight { from{opacity:0;transform:translateX(60px)} to{opacity:1;transform:translateX(0)} }
    `;
    document.head.appendChild(style);
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4500);
  }

  /* -------------------------------------------------------
     10. SMOOTH SCROLL for anchor links
  ------------------------------------------------------- */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* -------------------------------------------------------
     11. HERO PARALLAX
  ------------------------------------------------------- */
  const heroBg = document.querySelector('.hero-bg');
  if (heroBg) {
    window.addEventListener('scroll', () => {
      const scrolled = window.pageYOffset;
      heroBg.style.transform = `scale(1.05) translateY(${scrolled * 0.3}px)`;
    });
  }

  /* -------------------------------------------------------
     12. PACKAGE FILTER (packages page)
  ------------------------------------------------------- */
  const filterBtns = document.querySelectorAll('.filter-btn');
  if (filterBtns.length > 0) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        filterBtns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        document.querySelectorAll('.package-item').forEach(item => {
          if (filter === 'all' || item.dataset.category === filter) {
            item.style.display = 'block';
            item.style.animation = 'fadeInUp .4s ease';
          } else {
            item.style.display = 'none';
          }
        });
      });
    });
  }

  /* -------------------------------------------------------
     13. IMAGE LAZY LOADING (fallback)
  ------------------------------------------------------- */
  document.querySelectorAll('img[data-src]').forEach(img => {
    const imgObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          img.src = img.dataset.src;
          imgObserver.unobserve(img);
        }
      });
    });
    imgObserver.observe(img);
  });

  /* -------------------------------------------------------
     14. MOBILE MENU AUTO CLOSE
  ------------------------------------------------------- */
  const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
  const navbarCollapse = document.querySelector('.navbar-collapse');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (navbarCollapse && navbarCollapse.classList.contains('show')) {
        const toggler = document.querySelector('.navbar-toggler');
        if (toggler) toggler.click();
      }
    });
  });

  console.log('🐯 Satpura Safari Website Loaded Successfully!');
});
